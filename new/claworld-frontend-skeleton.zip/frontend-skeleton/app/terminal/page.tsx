// app/terminal/page.tsx
'use client';

import { useEffect } from 'react';
import { useAccount } from 'wagmi';
import { useRouter } from 'next/navigation';
import { NFASidebar } from '@/components/terminal/NFASidebar';
import { ConversationPane } from '@/components/terminal/ConversationPane';
import { StatusDrawer } from '@/components/terminal/StatusDrawer';
import { useEventStream } from '@/hooks/useEventStream';
import { useUIStore } from '@/lib/store';
import { useNFAs } from '@/hooks/useNFAs';

export default function TerminalPage() {
  const { isConnected } = useAccount();
  const router = useRouter();
  const { data } = useNFAs();
  const { selectedTokenId, select } = useUIStore();

  // redirect to landing if wallet disconnected
  useEffect(() => {
    if (!isConnected) router.replace('/');
  }, [isConnected, router]);

  // default-select the first NFA once loaded
  useEffect(() => {
    if (!selectedTokenId && data?.items?.length) select(data.items[0].tokenId);
  }, [data, selectedTokenId, select]);

  // live event stream for proactive NFA messages
  useEventStream(isConnected);

  return (
    <main className="h-screen w-screen bg-[#0a0807] text-amber-50 flex overflow-hidden">
      <NFASidebar nfas={data?.items ?? []} selectedId={selectedTokenId} onSelect={select} />

      <div className="flex-1 flex">
        <ConversationPane tokenId={selectedTokenId} />
        <StatusDrawer tokenId={selectedTokenId} />
      </div>
    </main>
  );
}
