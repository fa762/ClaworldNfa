// app/page.tsx  (Landing / wallet connect wall)
'use client';

import { useAccount, useSignMessage } from 'wagmi';
import { ConnectButton } from '@rainbow-me/rainbowkit';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { auth } from '@/lib/api';

export default function Landing() {
  const { address, isConnected } = useAccount();
  const { signMessageAsync } = useSignMessage();
  const router = useRouter();
  const [awakening, setAwakening] = useState(false);

  useEffect(() => {
    if (!isConnected || !address || awakening) return;
    (async () => {
      setAwakening(true);
      try {
        const { nonce } = await auth.nonce(address);
        const msg = buildSiweMessage(address, nonce);
        const sig = await signMessageAsync({ message: msg });
        await auth.verify(msg, sig);
        // brief "awakening" dwell then enter terminal
        setTimeout(() => router.push('/terminal'), 900);
      } catch {
        setAwakening(false);
      }
    })();
  }, [isConnected, address, awakening, signMessageAsync, router]);

  return (
    <main className="min-h-screen bg-[#0a0807] text-amber-50 relative overflow-hidden flex items-center justify-center">
      <AmbientBackground />

      <div className="relative z-10 text-center px-6">
        <div className="text-[11px] tracking-[0.4em] text-amber-500/70 mb-6">
          CLAWORLD · BNB CHAIN
        </div>
        <h1 className="font-display text-5xl md:text-7xl font-bold mb-6 leading-none">
          唤醒你的 NFA
        </h1>
        <p className="text-amber-50/60 max-w-md mx-auto mb-12 leading-relaxed">
          带记忆、能自治、在链上真实行动的 AI 伙伴
        </p>

        {awakening ? (
          <div className="text-amber-400 text-sm tracking-widest animate-pulse">
            AWAKENING...
          </div>
        ) : (
          <ConnectButton />
        )}
      </div>

      <footer className="absolute bottom-6 inset-x-0 text-center text-xs text-amber-50/30">
        BNB Chain Mainnet · ClawNFA 0xAa20…AE48
      </footer>
    </main>
  );
}

function buildSiweMessage(address: string, nonce: string) {
  const domain = typeof window !== 'undefined' ? window.location.host : 'clawnfaterminal.xyz';
  return [
    `${domain} wants you to sign in with your Ethereum account:`,
    address,
    '',
    'Enter the ClawNFA terminal.',
    '',
    `URI: https://${domain}`,
    `Version: 1`,
    `Chain ID: 56`,
    `Nonce: ${nonce}`,
    `Issued At: ${new Date().toISOString()}`,
  ].join('\n');
}

function AmbientBackground() {
  return (
    <>
      <div className="absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage:
            'linear-gradient(to right, #F5A524 1px, transparent 1px),' +
            'linear-gradient(to bottom, #F5A524 1px, transparent 1px)',
          backgroundSize: '80px 80px',
        }} />
      <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] rounded-full blur-[140px] opacity-20 bg-amber-500" />
      <div className="absolute bottom-1/4 right-1/3 w-[400px] h-[400px] rounded-full blur-[140px] opacity-10 bg-orange-600" />
    </>
  );
}
