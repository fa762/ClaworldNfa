// components/messages/MessageRenderer.tsx
'use client';

import type { Message } from '@/types/api';
import { TextBubble } from './TextBubble';
import { ActionProposalCard } from './ActionProposalCard';
import { ActionReceiptCard } from './ActionReceiptCard';
import { SystemEventCard } from './SystemEventCard';
import { WorldStateCardView } from './WorldStateCard';
import { ReasoningCardView } from './ReasoningCardView';

export function MessageRenderer({ message }: { message: Message }) {
  switch (message.type) {
    case 'text':            return <TextBubble m={message} />;
    case 'action_proposal': return <ActionProposalCard m={message} />;
    case 'action_receipt':  return <ActionReceiptCard m={message} />;
    case 'system_event':    return <SystemEventCard m={message} />;
    case 'world_state':     return <WorldStateCardView m={message} />;
    case 'reasoning':       return <ReasoningCardView m={message} />;
  }
}
