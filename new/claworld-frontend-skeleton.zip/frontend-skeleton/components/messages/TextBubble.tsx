// components/messages/TextBubble.tsx
import type { TextMessage } from '@/types/api';
import clsx from 'clsx';

export function TextBubble({ m }: { m: TextMessage }) {
  const isUser = m.author === 'user';
  return (
    <div className={clsx('flex', isUser ? 'justify-end' : 'justify-start')}>
      <div
        className={clsx(
          'max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed',
          isUser
            ? 'bg-amber-500/10 border border-amber-500/20 text-amber-50'
            : 'text-amber-50/90',
        )}
      >
        <p className="whitespace-pre-wrap">{m.content}</p>
        {m.memoryRef && (
          <div className="mt-2 text-[10px] text-amber-500/50 tracking-wide">
            recalled from {m.memoryRef.slice(0, 10)}…
          </div>
        )}
      </div>
    </div>
  );
}
