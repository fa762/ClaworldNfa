// components/messages/WorldStateCard.tsx
import type { WorldStateCard } from '@/types/api';
import { Activity } from 'lucide-react';

export function WorldStateCardView({ m }: { m: WorldStateCard }) {
  return (
    <div className="rounded-xl border border-amber-500/15 bg-gradient-to-br from-amber-500/5 to-transparent p-4 max-w-[520px]">
      <div className="flex items-center gap-2 text-xs text-amber-400/80 mb-2">
        <Activity size={12} />
        <span className="uppercase tracking-wider">{m.kind.replace(/_/g, ' ')}</span>
      </div>
      <p className="text-sm text-amber-50 mb-3">{m.content}</p>
      {m.ctaLabel && m.ctaSlashCommand && (
        <button
          className="text-xs px-3 py-1.5 rounded-lg border border-amber-500/30 hover:bg-amber-500/10 transition"
          onClick={() => {
            // consumers can wire a global event bus; for now, copy to composer
            window.dispatchEvent(new CustomEvent('claw:compose', { detail: m.ctaSlashCommand }));
          }}
        >
          {m.ctaLabel}
        </button>
      )}
    </div>
  );
}
