// components/messages/ActionReceiptCard.tsx
import type { ActionReceipt } from '@/types/api';
import { ExternalLink, Check, X, Clock } from 'lucide-react';
import clsx from 'clsx';

const STATUS = {
  pending: { icon: Clock,  color: 'text-amber-400',  label: 'PENDING' },
  success: { icon: Check,  color: 'text-green-400',  label: 'CONFIRMED' },
  failed:  { icon: X,      color: 'text-orange-400', label: 'FAILED' },
};

export function ActionReceiptCard({ m }: { m: ActionReceipt }) {
  const s = STATUS[m.status];
  const Icon = s.icon;

  return (
    <div className={clsx(
      'rounded-xl border bg-[#14100d] p-4 max-w-[520px]',
      m.status === 'failed' ? 'border-orange-500/30' : 'border-amber-500/15',
    )}>
      <div className="flex items-center gap-2 text-xs mb-2">
        <Icon size={12} className={s.color} />
        <span className={clsx('font-medium tracking-wide uppercase', s.color)}>{s.label}</span>
        <span className="text-amber-50/40 uppercase">· {m.skill}</span>
      </div>

      <p className="text-sm text-amber-50 mb-3">{m.summary}</p>

      <div className="space-y-1 text-xs">
        <Row label="cost" value={`${m.costCLW} CLW`} />
        {m.rewardCLW && <Row label="reward" value={`+${m.rewardCLW} CLW`} highlight />}
        {m.budgetRemainingCLW && (
          <Row label="remaining" value={`${m.budgetRemainingCLW} CLW`} />
        )}
        <Row
          label="tx"
          value={
            <a
              href={`https://bscscan.com/tx/${m.txHash}`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 hover:text-amber-400"
            >
              {m.txHash.slice(0, 10)}…{m.txHash.slice(-6)}
              <ExternalLink size={10} />
            </a>
          }
        />
        {m.reasoningCid && (
          <Row
            label="reasoning"
            value={
              <a
                href={`https://ipfs.io/ipfs/${m.reasoningCid}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 hover:text-amber-400"
              >
                {m.reasoningCid.slice(0, 12)}… <ExternalLink size={10} />
              </a>
            }
          />
        )}
        {m.hippocampusEntryId && (
          <Row label="memory" value={`written · ${m.hippocampusEntryId}`} />
        )}
      </div>

      {m.errorMessage && (
        <p className="mt-3 text-xs text-orange-300/80">{m.errorMessage}</p>
      )}
    </div>
  );
}

function Row({
  label, value, highlight,
}: { label: string; value: React.ReactNode; highlight?: boolean }) {
  return (
    <div className="flex justify-between gap-3">
      <span className="text-amber-50/40 uppercase tracking-wider">{label}</span>
      <span className={highlight ? 'text-green-400' : 'text-amber-50/85'}>{value}</span>
    </div>
  );
}
