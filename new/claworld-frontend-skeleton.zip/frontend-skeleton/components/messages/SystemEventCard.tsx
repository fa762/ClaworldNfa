// components/messages/SystemEventCard.tsx
import type { SystemEvent } from '@/types/api';
import { Sparkles } from 'lucide-react';

export function SystemEventCard({ m }: { m: SystemEvent }) {
  return (
    <div className="flex items-center gap-2 text-xs text-amber-500/50 justify-center py-1">
      <Sparkles size={10} />
      <span className="tracking-wide">{m.content}</span>
    </div>
  );
}
