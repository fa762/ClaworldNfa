// components/messages/ActionProposalCard.tsx
'use client';

import { useState } from 'react';
import type { ActionProposal } from '@/types/api';
import { actions } from '@/lib/api';
import { useSendTransaction } from 'wagmi';
import { Zap, Loader2 } from 'lucide-react';

export function ActionProposalCard({ m }: { m: ActionProposal }) {
  const { sendTransactionAsync } = useSendTransaction();
  const [state, setState] = useState<'idle' | 'preparing' | 'signing' | 'submitted'>('idle');

  const execute = async () => {
    setState('preparing');
    try {
      const tx = await actions.prepare(m.proposalId);
      setState('signing');
      const hash = await sendTransactionAsync({
        to: tx.to,
        data: tx.data,
        value: tx.value ? BigInt(tx.value) : undefined,
      });
      await actions.report(m.proposalId, hash);
      setState('submitted');
    } catch (e) {
      console.error(e);
      setState('idle');
    }
  };

  return (
    <div className="rounded-xl border border-amber-500/20 bg-[#14100d] p-4 max-w-[520px]">
      <div className="flex items-center gap-2 text-xs text-amber-500/80 mb-2">
        <Zap size={12} />
        <span className="font-medium tracking-wide uppercase">{m.skill}</span>
        {!m.requiresSignature && (
          <span className="ml-auto text-[10px] text-green-400/80">AUTO · WITHIN BUDGET</span>
        )}
      </div>

      <p className="text-sm text-amber-50 mb-3">{m.summary}</p>

      {m.details && m.details.length > 0 && (
        <dl className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-amber-50/60 mb-4">
          {m.details.map((d) => (
            <div key={d.label} className="flex justify-between">
              <dt>{d.label}</dt>
              <dd className="text-amber-50/90">{d.value}</dd>
            </div>
          ))}
        </dl>
      )}

      {m.requiresSignature && (
        <button
          onClick={execute}
          disabled={state !== 'idle'}
          className="w-full py-2 rounded-lg bg-amber-500 text-[#0a0807] text-sm font-medium disabled:opacity-50 hover:bg-amber-400 transition flex items-center justify-center gap-2"
        >
          {state === 'idle' && '执行'}
          {state === 'preparing' && <><Loader2 size={14} className="animate-spin" /> 准备交易</>}
          {state === 'signing' && <><Loader2 size={14} className="animate-spin" /> 等待签名</>}
          {state === 'submitted' && '已提交'}
        </button>
      )}
    </div>
  );
}
