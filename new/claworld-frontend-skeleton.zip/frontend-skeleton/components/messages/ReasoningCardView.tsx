// components/messages/ReasoningCardView.tsx
import type { ReasoningCard } from '@/types/api';
import { Brain, ExternalLink } from 'lucide-react';

export function ReasoningCardView({ m }: { m: ReasoningCard }) {
  return (
    <div className="rounded-xl border border-amber-500/10 bg-[#120e0b] p-3 max-w-[480px]">
      <div className="flex items-center gap-2 text-[10px] text-amber-500/70 uppercase tracking-wider mb-1">
        <Brain size={10} /> Reasoning Proof
      </div>
      <p className="text-xs text-amber-50/80 mb-2">{m.summary}</p>
      <a
        href={`https://ipfs.io/ipfs/${m.reasoningCid}`}
        target="_blank" rel="noreferrer"
        className="text-[10px] text-amber-400/70 hover:text-amber-400 inline-flex items-center gap-1 font-mono"
      >
        {m.reasoningCid} <ExternalLink size={9} />
      </a>
    </div>
  );
}
