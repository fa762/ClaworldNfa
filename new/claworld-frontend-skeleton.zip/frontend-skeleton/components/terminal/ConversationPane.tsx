// components/terminal/ConversationPane.tsx
'use client';

import { useEffect, useRef, useState } from 'react';
import { useChatHistory } from '@/hooks/useNFAs';
import { chat, parseSSE } from '@/lib/api';
import type { Message } from '@/types/api';
import { useQueryClient } from '@tanstack/react-query';
import { MessageRenderer } from '@/components/messages/MessageRenderer';
import { Send } from 'lucide-react';

interface Props {
  tokenId: string | null;
}

export function ConversationPane({ tokenId }: Props) {
  const { data } = useChatHistory(tokenId);
  const qc = useQueryClient();
  const [composing, setComposing] = useState('');
  const [streaming, setStreaming] = useState('');
  const [busy, setBusy] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: 1e9, behavior: 'smooth' });
  }, [data?.messages?.length, streaming]);

  if (!tokenId) return <EmptyState />;

  const messages: Message[] = data?.messages ?? [];

  const send = async () => {
    if (!composing.trim() || busy) return;
    const text = composing.trim();
    setComposing('');
    setBusy(true);
    setStreaming('');

    // optimistic user message
    qc.setQueryData(['chat', tokenId], (prev: any) => ({
      ...prev,
      messages: [
        ...(prev?.messages ?? []),
        {
          id: `tmp-${Date.now()}`,
          type: 'text',
          tokenId,
          author: 'user',
          createdAt: new Date().toISOString(),
          content: text,
        } as Message,
      ],
    }));

    try {
      const slash = text.startsWith('/') ? text.slice(1).split(/\s+/)[0] : undefined;
      const body = await chat.send(tokenId, text, slash);
      let accum = '';
      for await (const { event, data: payload } of parseSSE(body)) {
        if (event === 'token') {
          accum += (payload as any).delta ?? '';
          setStreaming(accum);
        } else if (event === 'card') {
          qc.setQueryData(['chat', tokenId], (prev: any) => ({
            ...prev,
            messages: [...(prev?.messages ?? []), payload],
          }));
        } else if (event === 'done') {
          if (accum) {
            qc.setQueryData(['chat', tokenId], (prev: any) => ({
              ...prev,
              messages: [
                ...(prev?.messages ?? []),
                {
                  id: (payload as any).messageId ?? `m-${Date.now()}`,
                  type: 'text',
                  tokenId,
                  author: 'nfa',
                  createdAt: new Date().toISOString(),
                  content: accum,
                } as Message,
              ],
            }));
          }
          setStreaming('');
        } else if (event === 'error') {
          console.error(payload);
        }
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="flex-1 flex flex-col min-w-0 bg-[#0a0807]">
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-6 py-8">
        <div className="max-w-3xl mx-auto space-y-6">
          {messages.map((m) => <MessageRenderer key={m.id} message={m} />)}
          {streaming && (
            <div className="text-amber-50/90 leading-relaxed">
              {streaming}
              <span className="inline-block w-2 h-4 bg-amber-400/60 ml-1 animate-pulse" />
            </div>
          )}
        </div>
      </div>

      <div className="border-t border-amber-500/10 px-6 py-4">
        <div className="max-w-3xl mx-auto flex items-end gap-3">
          <textarea
            value={composing}
            onChange={(e) => setComposing(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
            }}
            placeholder="告诉你的 NFA 该做什么,或输入 / 查看快捷命令"
            rows={1}
            className="flex-1 bg-[#14100d] border border-amber-500/15 rounded-xl px-4 py-3 text-sm resize-none focus:outline-none focus:border-amber-500/40 max-h-40"
          />
          <button
            onClick={send}
            disabled={busy || !composing.trim()}
            className="w-11 h-11 rounded-xl bg-amber-500 text-[#0a0807] disabled:opacity-30 disabled:bg-amber-500/40 hover:bg-amber-400 transition flex items-center justify-center"
          >
            <Send size={16} />
          </button>
        </div>
      </div>
    </section>
  );
}

function EmptyState() {
  return (
    <section className="flex-1 flex items-center justify-center text-amber-50/30">
      <p>Select an NFA to begin</p>
    </section>
  );
}
