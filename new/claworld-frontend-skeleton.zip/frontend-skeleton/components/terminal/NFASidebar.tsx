// components/terminal/NFASidebar.tsx
'use client';

import { Plus } from 'lucide-react';
import type { NFASummary } from '@/types/api';
import clsx from 'clsx';

interface Props {
  nfas: NFASummary[];
  selectedId: string | null;
  onSelect: (tokenId: string) => void;
}

export function NFASidebar({ nfas, selectedId, onSelect }: Props) {
  return (
    <aside className="w-[72px] shrink-0 border-r border-amber-500/10 bg-[#0d0a08] flex flex-col items-center py-4 gap-2">
      {nfas.map((n) => (
        <NFAAvatar
          key={n.tokenId}
          nfa={n}
          selected={n.tokenId === selectedId}
          onClick={() => onSelect(n.tokenId)}
        />
      ))}

      <div className="flex-1" />

      <button
        className="w-12 h-12 rounded-2xl border border-dashed border-amber-500/30 flex items-center justify-center text-amber-500/60 hover:border-amber-500/60 hover:text-amber-400 transition"
        aria-label="Genesis Mint"
      >
        <Plus size={18} />
      </button>
    </aside>
  );
}

function NFAAvatar({ nfa, selected, onClick }: {
  nfa: NFASummary; selected: boolean; onClick: () => void;
}) {
  const accent = nfa.accentColor ?? '#F5A524';
  return (
    <div className="relative group">
      {selected && (
        <span
          className="absolute -left-3 top-1/2 -translate-y-1/2 w-[3px] h-6 rounded-r"
          style={{ background: accent }}
        />
      )}
      <button
        onClick={onClick}
        className={clsx(
          'w-12 h-12 overflow-hidden transition-all relative',
          selected ? 'rounded-full' : 'rounded-2xl hover:rounded-3xl',
        )}
        style={{ boxShadow: selected ? `0 0 0 2px ${accent}40` : undefined }}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={nfa.avatarUri} alt={nfa.displayName} className="w-full h-full object-cover" />
        {!nfa.active && <span className="absolute inset-0 bg-black/50" />}
        {nfa.unreadCount > 0 && !selected && (
          <span
            className="absolute top-0 right-0 w-3 h-3 rounded-full border-2 border-[#0d0a08]"
            style={{ background: accent }}
          />
        )}
      </button>

      {/* tooltip */}
      <div className="absolute left-full ml-3 top-1/2 -translate-y-1/2 px-3 py-1.5 rounded-md bg-[#1a1512] border border-amber-500/20 text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition z-50">
        <div className="font-medium">{nfa.displayName}</div>
        <div className="text-amber-50/50 text-[10px]">Lv.{nfa.level} · {nfa.ledgerBalanceCLW} CLW</div>
      </div>
    </div>
  );
}
