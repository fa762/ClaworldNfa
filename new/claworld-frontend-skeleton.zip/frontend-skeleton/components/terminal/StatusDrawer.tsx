// components/terminal/StatusDrawer.tsx
'use client';

import { useNFADetail, useMemorySummary, useAutonomyStatus, usePauseAutonomy } from '@/hooks/useNFAs';
import { useUIStore } from '@/lib/store';
import { ChevronRight, Wallet, Brain, Shield, PauseCircle } from 'lucide-react';
import clsx from 'clsx';

interface Props { tokenId: string | null; }

export function StatusDrawer({ tokenId }: Props) {
  const { statusDrawerOpen, toggleDrawer } = useUIStore();
  const { data: nfa } = useNFADetail(tokenId);
  const { data: mem } = useMemorySummary(tokenId);
  const { data: aut } = useAutonomyStatus(tokenId);
  const pauseM = usePauseAutonomy(tokenId ?? '');

  if (!tokenId) return null;

  return (
    <aside
      className={clsx(
        'border-l border-amber-500/10 bg-[#0d0a08] transition-all shrink-0 overflow-hidden',
        statusDrawerOpen ? 'w-[320px]' : 'w-[44px]',
      )}
    >
      <button
        onClick={toggleDrawer}
        className="w-full h-12 flex items-center justify-center text-amber-500/60 hover:text-amber-400 border-b border-amber-500/10"
      >
        <ChevronRight
          size={16}
          className={clsx('transition-transform', statusDrawerOpen && 'rotate-180')}
        />
      </button>

      {statusDrawerOpen && (
        <div className="p-4 space-y-6 overflow-y-auto">
          {nfa && (
            <header className="pb-4 border-b border-amber-500/10">
              <div className="text-xs text-amber-500/60 uppercase tracking-wider mb-1">
                #{nfa.tokenId} · Lv.{nfa.level}
              </div>
              <div className="text-lg font-medium">{nfa.displayName}</div>
              <div className="text-xs text-amber-50/50">{nfa.rarity} · {nfa.shelter}</div>
            </header>
          )}

          {/* Ledger */}
          <Section icon={Wallet} title="Ledger">
            {nfa && (
              <>
                <Row label="Balance" value={`${nfa.ledgerBalanceCLW} CLW`} />
                <div className="flex gap-2 mt-3">
                  <Btn>Deposit</Btn>
                  <Btn>Withdraw</Btn>
                </div>
              </>
            )}
          </Section>

          {/* Memory */}
          <Section icon={Brain} title="Memory">
            {mem && (
              <>
                <Row label="Pulse" value={`${Math.round(mem.pulse * 100)}%`} />
                <Row label="Buffer" value={`${mem.hippocampusSize} entries`} />
                <Row
                  label="Anchor"
                  value={
                    mem.latestAnchorTxHash ? (
                      <a
                        href={`https://bscscan.com/tx/${mem.latestAnchorTxHash}`}
                        target="_blank" rel="noreferrer"
                        className="hover:text-amber-400 font-mono text-[11px]"
                      >
                        {mem.latestAnchorTxHash.slice(0, 8)}…
                      </a>
                    ) : '—'
                  }
                />
                {mem.identity && (
                  <p className="text-xs text-amber-50/60 mt-3 leading-relaxed italic">
                    "{mem.identity}"
                  </p>
                )}
              </>
            )}
          </Section>

          {/* Autonomy */}
          <Section icon={Shield} title="Autonomy">
            {aut && (
              <>
                <Row
                  label="Status"
                  value={
                    <span className={aut.paused ? 'text-orange-400' : aut.enabled ? 'text-green-400' : 'text-amber-50/40'}>
                      {aut.paused ? 'Paused' : aut.enabled ? 'Active' : 'Off'}
                    </span>
                  }
                />
                {aut.enabled && (
                  <>
                    <BudgetBar
                      used={aut.budget.usedCLW}
                      total={aut.budget.totalCLW}
                    />
                    {aut.directive?.text && (
                      <p className="text-xs text-amber-50/60 mt-3 leading-relaxed">
                        {aut.directive.text}
                      </p>
                    )}
                    <button
                      onClick={() => pauseM.mutate()}
                      className="mt-3 w-full py-2 text-xs rounded-lg border border-orange-500/40 text-orange-400 hover:bg-orange-500/10 transition flex items-center justify-center gap-1"
                    >
                      <PauseCircle size={12} /> Emergency Stop
                    </button>
                  </>
                )}
              </>
            )}
          </Section>
        </div>
      )}
    </aside>
  );
}

function Section({
  icon: Icon, title, children,
}: { icon: any; title: string; children: React.ReactNode }) {
  return (
    <section>
      <h3 className="flex items-center gap-2 text-[11px] uppercase tracking-wider text-amber-500/70 mb-3">
        <Icon size={11} /> {title}
      </h3>
      <div className="space-y-1.5 text-xs">{children}</div>
    </section>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex justify-between gap-3">
      <span className="text-amber-50/40">{label}</span>
      <span className="text-amber-50/90">{value}</span>
    </div>
  );
}

function Btn({ children }: { children: React.ReactNode }) {
  return (
    <button className="flex-1 py-1.5 rounded-lg border border-amber-500/20 hover:border-amber-500/40 hover:bg-amber-500/5 text-xs transition">
      {children}
    </button>
  );
}

function BudgetBar({ used, total }: { used: string; total: string }) {
  const u = Number(used) || 0;
  const t = Number(total) || 1;
  const pct = Math.min(100, (u / t) * 100);
  return (
    <div className="mt-3">
      <div className="flex justify-between text-[10px] text-amber-50/50 mb-1">
        <span>Budget</span>
        <span>{used} / {total} CLW</span>
      </div>
      <div className="h-1.5 bg-amber-500/10 rounded-full overflow-hidden">
        <div
          className="h-full bg-amber-500 transition-all"
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}
