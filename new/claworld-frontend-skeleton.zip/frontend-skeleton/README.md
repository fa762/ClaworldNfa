# ClaworldNfa 新前端骨架

此目录是可直接丢进现有 `frontend/` 目录起步的 **Next.js 14 App Router** 骨架。
实现了对话式 dApp 的主体结构:

```
app/
  page.tsx              # Landing — wallet connect wall + SIWE
  terminal/
    page.tsx            # Terminal main shell

components/
  terminal/
    NFASidebar.tsx      # 左栏: Discord 式 NFA 频道
    ConversationPane.tsx# 中央对话流 + 输入
    StatusDrawer.tsx    # 右侧可折叠面板
  messages/
    MessageRenderer.tsx # 多态消息分发
    TextBubble.tsx
    ActionProposalCard.tsx
    ActionReceiptCard.tsx
    SystemEventCard.tsx
    WorldStateCard.tsx
    ReasoningCardView.tsx

hooks/
  useNFAs.ts            # TanStack Query hooks
  useEventStream.ts     # SSE 订阅 + cache 注入

lib/
  api.ts                # BFF client + SSE 工具
  store.ts              # Zustand UI state

types/
  api.ts                # 映射 openapi.yaml 的 TS 类型
```

## 需要安装的依赖

```bash
npm i next@14 react react-dom
npm i wagmi viem @rainbow-me/rainbowkit
npm i @tanstack/react-query
npm i zustand
npm i clsx lucide-react
```

## 必需的全局配置 (未包含在骨架内, 在你项目里已有可跳过)

1. **wagmi + RainbowKit provider** — 用你现有的 BNB Chain config
2. **TanStack QueryClientProvider** — 包裹 `app/layout.tsx`
3. **Tailwind + 字体** — 方案文档里建议 Display: Space Mono, Body: Satoshi/Geist
4. **环境变量** `NEXT_PUBLIC_API_BASE` — 默认 `/api`

## BFF 实现位置

两种方式:
- **Next.js API Routes**: 在同一个 Next 应用下创建 `app/api/nfas/route.ts` 等,适合快速启动
- **独立 Node 服务**: `openclaw/` 相邻目录下起一个 Fastify/NestJS 服务,长期更好扩展

骨架中 `lib/api.ts` 的调用路径已与 `openapi.yaml` 完全对齐,BFF 实现按 schema 走即可。

## 下一步

1. 补全 BFF 实现 (按 openapi.yaml)
2. 接入 runtime 的事件总线到 SSE 端点
3. 补 directive 签名对话流程 (在 ConversationPane 里处理特殊 action type)
4. 移动端响应式: `<1024px` 左栏变顶部带,右栏变滑入 drawer
5. 对话历史虚拟化 (react-virtuoso) 防止长会话卡顿
