// hooks/useNFAs.ts
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { nfa, chat, memory, autonomy } from '@/lib/api';

export function useNFAs() {
  return useQuery({
    queryKey: ['nfas'],
    queryFn: () => nfa.list(),
    staleTime: 30_000,
  });
}

export function useNFADetail(tokenId: string | null) {
  return useQuery({
    queryKey: ['nfa', tokenId],
    queryFn: () => nfa.detail(tokenId!),
    enabled: !!tokenId,
  });
}

export function useChatHistory(tokenId: string | null) {
  return useQuery({
    queryKey: ['chat', tokenId],
    queryFn: () => chat.history(tokenId!),
    enabled: !!tokenId,
  });
}

export function useMemorySummary(tokenId: string | null) {
  return useQuery({
    queryKey: ['memory', 'summary', tokenId],
    queryFn: () => memory.summary(tokenId!),
    enabled: !!tokenId,
    staleTime: 15_000,
  });
}

export function useAutonomyStatus(tokenId: string | null) {
  return useQuery({
    queryKey: ['autonomy', tokenId],
    queryFn: () => autonomy.status(tokenId!),
    enabled: !!tokenId,
    staleTime: 10_000,
  });
}

export function usePauseAutonomy(tokenId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => autonomy.pause(tokenId),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['autonomy', tokenId] }),
  });
}
