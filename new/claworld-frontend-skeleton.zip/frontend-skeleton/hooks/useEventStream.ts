// hooks/useEventStream.ts
import { useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { openEventStream } from '@/lib/api';
import type { RuntimeEvent } from '@/types/api';

/**
 * Subscribes to the BFF SSE event stream. Routes each event to:
 *  - cache invalidation (so right panel stays fresh)
 *  - chat cache append (so NFA-initiated messages show up in the stream)
 *  - unread counter bump (sidebar badge)
 */
export function useEventStream(enabled: boolean) {
  const qc = useQueryClient();

  useEffect(() => {
    if (!enabled) return;
    const close = openEventStream((e: RuntimeEvent) => {
      const tokenId = e.tokenId;

      // 1. Invalidate relevant queries
      switch (e.type) {
        case 'autonomy.action_completed':
        case 'autonomy.action_failed':
        case 'directive.updated':
          qc.invalidateQueries({ queryKey: ['autonomy', tokenId] });
          qc.invalidateQueries({ queryKey: ['nfa', tokenId] });
          break;
        case 'cml.sleep_consolidated':
          qc.invalidateQueries({ queryKey: ['memory', 'summary', tokenId] });
          qc.invalidateQueries({ queryKey: ['memory', 'timeline', tokenId] });
          break;
        case 'ledger.low_balance':
        case 'ledger.reward_received':
          qc.invalidateQueries({ queryKey: ['nfa', tokenId] });
          qc.invalidateQueries({ queryKey: ['nfas'] });
          break;
      }

      // 2. If payload is a Message, append to chat cache
      qc.setQueryData(['chat', tokenId], (prev: any) => {
        if (!prev) return prev;
        return { ...prev, messages: [...prev.messages, e.payload] };
      });

      // 3. Bump unread count on the NFA summary if it's not selected
      qc.setQueryData(['nfas'], (prev: any) => {
        if (!prev?.items) return prev;
        return {
          items: prev.items.map((n: any) =>
            n.tokenId === tokenId ? { ...n, unreadCount: n.unreadCount + 1 } : n,
          ),
        };
      });
    });
    return close;
  }, [enabled, qc]);
}
