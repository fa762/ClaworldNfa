// lib/api.ts
import type {
  NFASummary, NFADetail, Message, MemorySummary, MemorySnapshot,
  AutonomyStatus, TxRequest, RuntimeEvent,
} from '@/types/api';

const BASE = process.env.NEXT_PUBLIC_API_BASE || '/api';

async function req<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...init?.headers },
    ...init,
  });
  if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

// ─── Auth ───────────────────────────────────────────────────────────
export const auth = {
  nonce: (address: string) =>
    req<{ nonce: string; issuedAt: string }>(`/auth/nonce?address=${address}`),
  verify: (message: string, signature: string) =>
    req<{ address: string; expiresAt: string }>('/auth/verify', {
      method: 'POST',
      body: JSON.stringify({ message, signature }),
    }),
  logout: () => req<void>('/auth/logout', { method: 'POST' }),
};

// ─── NFA ────────────────────────────────────────────────────────────
export const nfa = {
  list: () => req<{ items: NFASummary[] }>('/nfas'),
  detail: (tokenId: string) => req<NFADetail>(`/nfas/${tokenId}`),
  rename: (tokenId: string, name: string) =>
    req<void>(`/nfas/${tokenId}/rename`, { method: 'POST', body: JSON.stringify({ name }) }),
};

// ─── Chat ───────────────────────────────────────────────────────────
export const chat = {
  history: (tokenId: string, before?: string, limit = 50) => {
    const qs = new URLSearchParams({ limit: String(limit) });
    if (before) qs.set('before', before);
    return req<{ messages: Message[]; nextBefore: string | null }>(
      `/chat/${tokenId}/history?${qs}`,
    );
  },
  /** Send a message; returns an SSE reader. Consumer should `for await` it. */
  send: async (
    tokenId: string,
    content: string,
    slashCommand?: string,
    slashArgs?: Record<string, unknown>,
  ) => {
    const res = await fetch(`${BASE}/chat/${tokenId}/send`, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json', Accept: 'text/event-stream' },
      body: JSON.stringify({ content, slashCommand, slashArgs }),
    });
    if (!res.ok || !res.body) throw new Error(`chat send failed: ${res.status}`);
    return res.body; // consumed via parseSSE()
  },
};

// ─── Actions ────────────────────────────────────────────────────────
export const actions = {
  prepare: (proposalId: string) =>
    req<TxRequest>('/actions/prepare', {
      method: 'POST',
      body: JSON.stringify({ proposalId }),
    }),
  report: (proposalId: string, txHash: string) =>
    req<void>('/actions/report', {
      method: 'POST',
      body: JSON.stringify({ proposalId, txHash }),
    }),
};

// ─── Memory ─────────────────────────────────────────────────────────
export const memory = {
  summary: (tokenId: string) => req<MemorySummary>(`/memory/${tokenId}/summary`),
  timeline: (tokenId: string, limit = 20) =>
    req<{ snapshots: MemorySnapshot[] }>(`/memory/${tokenId}/timeline?limit=${limit}`),
};

// ─── Autonomy ───────────────────────────────────────────────────────
export const autonomy = {
  status: (tokenId: string) => req<AutonomyStatus>(`/autonomy/${tokenId}/status`),
  prepareDirective: (tokenId: string, body: {
    text: string; budgetCLW: string; skills: string[]; expiresAt?: string;
  }) => req<{ message: string; nonce: string }>(
    `/autonomy/${tokenId}/directive/prepare`,
    { method: 'POST', body: JSON.stringify(body) },
  ),
  commitDirective: (tokenId: string, message: string, signature: string, nonce: string) =>
    req<void>(`/autonomy/${tokenId}/directive/commit`, {
      method: 'POST',
      body: JSON.stringify({ message, signature, nonce }),
    }),
  pause: (tokenId: string) => req<void>(`/autonomy/${tokenId}/pause`, { method: 'POST' }),
  resume: (tokenId: string) => req<void>(`/autonomy/${tokenId}/resume`, { method: 'POST' }),
};

// ─── SSE event stream ───────────────────────────────────────────────
export function openEventStream(onEvent: (e: RuntimeEvent) => void, lastEventId?: string) {
  const url = new URL(`${BASE}/events/stream`, window.location.origin);
  const es = new EventSource(url, { withCredentials: true } as EventSourceInit);
  if (lastEventId) (es as any).lastEventId = lastEventId;
  es.onmessage = (msg) => {
    try { onEvent(JSON.parse(msg.data)); } catch { /* ignore */ }
  };
  // Server uses `event:` field; listen for each known type as needed
  const types: string[] = [
    'autonomy.action_completed', 'autonomy.action_failed',
    'battle_royale.opening_soon', 'battle_royale.result',
    'cml.sleep_consolidated', 'ledger.low_balance', 'ledger.reward_received',
    'market.opportunity_matched', 'directive.updated',
  ];
  types.forEach(t => es.addEventListener(t, (e: MessageEvent) => {
    try { onEvent({ ...JSON.parse(e.data), type: t as any }); } catch { /* ignore */ }
  }));
  return () => es.close();
}

// ─── SSE reader utility for chat streaming ──────────────────────────
export async function* parseSSE(body: ReadableStream<Uint8Array>) {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const chunks = buffer.split('\n\n');
    buffer = chunks.pop() ?? '';
    for (const chunk of chunks) {
      const lines = chunk.split('\n');
      let event = 'message';
      let data = '';
      for (const line of lines) {
        if (line.startsWith('event:')) event = line.slice(6).trim();
        else if (line.startsWith('data:')) data += line.slice(5).trim();
      }
      if (data) {
        try { yield { event, data: JSON.parse(data) }; }
        catch { yield { event, data }; }
      }
    }
  }
}
