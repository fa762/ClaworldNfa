// lib/store.ts
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface UIStore {
  selectedTokenId: string | null;
  statusDrawerOpen: boolean;
  select: (tokenId: string) => void;
  toggleDrawer: () => void;
  setDrawer: (open: boolean) => void;
}

export const useUIStore = create<UIStore>()(
  persist(
    (set) => ({
      selectedTokenId: null,
      statusDrawerOpen: false,
      select: (tokenId) => set({ selectedTokenId: tokenId }),
      toggleDrawer: () => set((s) => ({ statusDrawerOpen: !s.statusDrawerOpen })),
      setDrawer: (open) => set({ statusDrawerOpen: open }),
    }),
    { name: 'claw-ui' },
  ),
);
