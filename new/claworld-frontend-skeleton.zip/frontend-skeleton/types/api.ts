// types/api.ts
// Mirrors the BFF OpenAPI schema. Keep in sync with openapi.yaml.

export type Address = `0x${string}`;
export type Hex = `0x${string}`;

// ─── NFA ────────────────────────────────────────────────────────────
export interface NFASummary {
  tokenId: string;
  displayName: string;
  avatarUri: string;
  accentColor?: string;
  level: number;
  active: boolean;
  pulse: number; // 0..1
  ledgerBalanceCLW: string;
  unreadCount: number;
}

export interface NFADetail extends NFASummary {
  rarity: string;
  shelter: string;
  personalityVector: number[];
  dnaTraits: Record<string, unknown>;
  greeting?: string;
  tokenURI: string;
}

// ─── Messages ───────────────────────────────────────────────────────
export type MessageAuthor = 'user' | 'nfa' | 'system';

export interface MessageBase {
  id: string;
  tokenId: string;
  author: MessageAuthor;
  createdAt: string;
}

export interface TextMessage extends MessageBase {
  type: 'text';
  content: string;
  memoryRef?: string;
}

export type SkillName = 'task' | 'pk' | 'battle_royale' | 'market' | 'router' | 'mint';

export interface ActionProposal extends MessageBase {
  type: 'action_proposal';
  proposalId: string;
  skill: SkillName;
  summary: string;
  details?: Array<{ label: string; value: string }>;
  estimatedCostCLW?: string;
  estimatedGasBNB?: string;
  requiresSignature: boolean;
  expiresAt: string;
}

export type ActionStatus = 'pending' | 'success' | 'failed';

export interface ActionReceipt extends MessageBase {
  type: 'action_receipt';
  actionId: string;
  skill: SkillName;
  status: ActionStatus;
  txHash: Hex;
  blockNumber?: number;
  summary: string;
  costCLW: string;
  rewardCLW?: string;
  gasBNB?: string;
  reasoningCid?: string;
  hippocampusEntryId?: string;
  budgetRemainingCLW?: string;
  errorMessage?: string;
}

export type SystemEventType =
  | 'cml.sleep_consolidated'
  | 'ledger.low_balance'
  | 'ledger.reward_received'
  | 'autonomy.paused'
  | 'autonomy.resumed'
  | 'directive.updated';

export interface SystemEvent extends MessageBase {
  type: 'system_event';
  eventType: SystemEventType;
  content: string;
  metadata?: Record<string, unknown>;
}

export interface WorldStateCard extends MessageBase {
  type: 'world_state';
  kind: 'battle_royale_opening' | 'market_opportunity' | 'pk_challenge';
  content: string;
  ctaLabel?: string;
  ctaSlashCommand?: string;
}

export interface ReasoningCard extends MessageBase {
  type: 'reasoning';
  reasoningCid: string;
  summary: string;
  linkedActionId?: string;
}

export type Message =
  | TextMessage
  | ActionProposal
  | ActionReceipt
  | SystemEvent
  | WorldStateCard
  | ReasoningCard;

// ─── Memory ─────────────────────────────────────────────────────────
export interface MemorySummary {
  latestSnapshotHash: string;
  latestAnchorTxHash?: string;
  pulse: number;
  hippocampusSize: number;
  identity: string;
  prefrontalBeliefs?: string[];
  basalHabits?: string[];
}

export interface MemorySnapshot {
  snapshotId: string;
  hash: string;
  consolidatedAt: string;
  anchorTxHash?: string;
  greenfieldUri?: string;
  diffSummary?: string;
  hippocampusMerged?: number;
}

// ─── Autonomy ───────────────────────────────────────────────────────
export interface AutonomyStatus {
  enabled: boolean;
  paused: boolean;
  directive: {
    text: string;
    signedAt: string;
    expiresAt?: string;
    skills: string[];
    onchainNonce?: string;
  } | null;
  budget: {
    totalCLW: string;
    usedCLW: string;
    remainingCLW: string;
    windowStart?: string;
  };
  recentActions: ActionReceipt[];
}

// ─── Runtime SSE ────────────────────────────────────────────────────
export type RuntimeEventType =
  | 'autonomy.action_completed'
  | 'autonomy.action_failed'
  | 'battle_royale.opening_soon'
  | 'battle_royale.result'
  | 'cml.sleep_consolidated'
  | 'ledger.low_balance'
  | 'ledger.reward_received'
  | 'market.opportunity_matched'
  | 'directive.updated';

export interface RuntimeEvent {
  id: string;
  type: RuntimeEventType;
  tokenId: string;
  timestamp: string;
  payload: ActionReceipt | SystemEvent | WorldStateCard;
}

// ─── Transaction prep ───────────────────────────────────────────────
export interface TxRequest {
  to: Address;
  data: Hex;
  value?: string;
  chainId: number;
  gasHint?: string;
  humanReadable?: string;
}
